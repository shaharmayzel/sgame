
export const environment = {
    production: true,
    firebase: {
        apiKey: "AIzaSyDY_eZqTOBbUZMitnKSmqxZlkZbn4asXUg",
        authDomain: "squares-28edf.firebaseapp.com",
        projectId: "squares-28edf",
        storageBucket: "squares-28edf.appspot.com",
        messagingSenderId: "374516239185",
        appId: "1:374516239185:web:be19dfc169698195e12170",
        measurementId: "G-Z80M92CV4Q"
    }


};