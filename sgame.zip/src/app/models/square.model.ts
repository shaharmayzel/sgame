export interface Square {
    color: any
    id: number
}