import { Component, OnInit, Input } from '@angular/core';
import { HostListener } from '@angular/core';
import { Square } from 'src/app/models/square.model';
import { SquareService } from '../../services/square.service'
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';


@Component({
  selector: 'app-square-preview',
  templateUrl: './square-preview.component.html',
  styleUrls: ['./square-preview.component.scss']
})
export class SquarePreviewComponent implements OnInit {

  constructor(private squareService: SquareService) { }
  @Input() square: Square


  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  )

  renderer = null
  light = new THREE.PointLight(0xFFFFFF, 1, 500)
  geometry = null
  material = null
  mesh = null
  renderRequested = false;
  raycaster = null
  currPos = 20
  mouse = null
  click = false

  ngOnInit(): void {
    console.log('read');

    const id = this.square.id
    let renderers = this.squareService.renderers
    console.log(id);
    console.log(renderers);


    if (renderers.hasOwnProperty(id)) {
      this.renderer = renderers[id]

    }
    else {
      this.renderer = new THREE.WebGLRenderer({ antialias: true })
      this.squareService.renderers[id] = this.renderer
    }

    this.startScene()

  }

  startScene(): void {
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    this.renderer.setClearColor("#fff")
    this.light.position.set(10, 0, 25)
    this.renderer.setSize(window.innerWidth / 3, window.innerHeight / 3)
    this.camera.position.z = 2

    document.getElementsByClassName("square-wrap")[0].appendChild(this.renderer.domElement);
    this.renderer.domElement.addEventListener('click', this.onMouseMove)
    console.log(123);

    window.addEventListener('resize', () => { //resize
      this.renderer.setSize(window.innerWidth / 3, window.innerHeight / 3);
      this.camera.aspect = (window.innerWidth / 3) / (window.innerHeight / 3)

      this.camera.updateProjectionMatrix();

    })

    this.addObject()
  }



  addObject(): void {

    this.geometry = new THREE.BoxGeometry(1, 1, 1);
    this.material = new THREE.MeshLambertMaterial({
      color: this.square.color
    })
    this.mesh = new THREE.Mesh(this.geometry, this.material)

    this.scene.add(this.mesh);
    this.light.position.set(10, 0, 25)
    this.scene.add(this.light)

    this.render()


  }


  render = (): any => {

    requestAnimationFrame(this.render)

    this.mesh.rotation.x += 0.01
    this.renderer.render(this.scene, this.camera)

  }


  onMouseMove = (event): void => {

    // event.preventDefault();

    // this.mouse.x = (event.clientX / (window.innerWidth / 3)) * 2 - 1;
    // this.mouse.y = - (event.clientY / (window.innerHeight / 3)) * 2 + 1;






    let color = Math.random() * 0xffffff


    this.square.color = color
    this.squareService.updateSquare(this.square)





  }

  // this.rend?er()

}






